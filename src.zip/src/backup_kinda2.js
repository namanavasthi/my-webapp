
<li><Link activeClass="active" className="Home" to="Home" spy={true} smooth={true} duration={500} >Home</Link></li>
<li><Link activeClass="active" className="About" to="About" spy={true} smooth={true} duration={500} >About</Link></li>
<li><Link activeClass="active" className="Projects" to="Projects" spy={true} smooth={true} duration={500} >Projects</Link></li>
<li><Link activeClass="active" className="Contact" to="Contact" spy={true} smooth={true} duration={500} >Contact</Link></li>



<Element name="Home">

<Element name="About">

<Element name="Projects" className="element">
            
          </Element>

          <Element name="Contact" className="element">
            
          </Element>