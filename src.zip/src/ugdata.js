export const DATA = [
  {
    headerName: 'First Year',
    isOpened: false,
    // isReactComponent: false,
      items: [{
        title: 'Applied Mathematics-I, Applied Physics-I, Applied Chemistry-I, Engineering Mechanics, Basic Electrical & Electronics Engineering, Computer Programming-I, Basic Workshop & Practice-I '
      },
      {
        title: 'Applied Mathematics-II, Applied Physics-II, Applied Chemistry-II, Communication Skills, Engineering Drawing, Computer Programming-II, Basic Workshop & Practice-II'
      }],
    height: 175
  },
  {
    headerName: 'Second Year',
    isOpened: false,
    // isReactComponent: false,
      items: [{
        title: 'Applied Mathematics-III, Electronic Devices & Linear Circuits, Discrete Structures & Graph Theory, Digital Logic Design & Applications, Data Structures & Files, Computer Organization & Architecture, Presentation & Communication Techniques'
      },
      {
        title: 'Applied Mathematics-IV, Analog & Digital Communication, Database Management System, Computer Graphics, Analysis of Algorithm and Design, Operatin system'
      }],
    height: 205
  },
  {
    headerName: 'Third Year',
    isOpened: false,
    // isReactComponent: false,
      items: [{
        title: 'Computer Network, Advanced Database Management System, Microprocessor, Theory of Computer Science, Web Engineering, Environment Studies'
      },
      {
        title: 'Advanced Computer Network, System Programming & Compiler Construction, Object Oriented Software Engineering, Advanced Microprocessor, Data Warehouse & Mining, Seminar'
      }],
    height: 150
  },
  {
    headerName: 'Fourth Year',
    isOpened: false,
    
      items: [{
        title: 'Digital Signal & Image Processing, Robotics & AI, Mobile Computing, System Security, Project Management, Project-I'
      },
      {
        title: 'Distributed Computing, Multimedia System Design, Software Architecture, Computer Vision, Project-II'
      }],
    height: 150
  }
]